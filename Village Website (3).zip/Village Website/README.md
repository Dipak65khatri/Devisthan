# village-project
Html, CSS , Sass and javascript for our community project
